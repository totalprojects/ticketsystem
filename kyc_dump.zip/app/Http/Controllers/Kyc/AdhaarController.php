<?php

namespace App\Http\Controllers\Kyc;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Traits\AdhaarVerification;

class AdhaarController extends Controller
{
    use AdhaarVerification;
    //
    public function index() {

        $data['page_title'] = "Adhaar Verification";

        return view('adhaar-verification.index')->with($data);
    }

    public function verifyAdhaarCard(Request $request) {


        return $this->verifyAdhaar($request);
    }
}
