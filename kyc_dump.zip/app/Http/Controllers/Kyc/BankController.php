<?php

namespace App\Http\Controllers\Kyc;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Traits\BankVerification;

class BankController extends Controller
{
    use BankVerification;
    //
    public function index() {

        $data['page_title'] = "Bank Verification";

        return view('bank-verification.index')->with($data);
    }


    public function verifyBank(Request $request) {

        $data['page_title'] = "Bank Verification";
        $params = [
            'account_no' => $request->account_no,
            'ifsc_code'  => $request->ifsc_code
        ];
        return $this->verifyAccount($params);
    }


}
