<?php

namespace App\Http\Controllers\Kyc;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Traits\PanVerification;

class PanController extends Controller
{
    //
    use PanVerification;

    public function index() {

        $data['page_title'] = "Pan Verification";

        return view('pan-verification.index')->with($data);
    }


    public function verifyPanCard(Request $request) {


        return $this->verifyPan($request);
    }
}
