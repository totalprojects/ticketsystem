<?php

namespace App\Http\Controllers\Permission;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Permission;

class PermissionController extends Controller
{
    //
     /**
     * @return view of users
     */
    public function index(){
        
        return view('permission.index');
    }

    public function fetchPermissions() {
        $roles = Permission::all();
        $totalCount = count($roles);
        return response(['data'=>$roles,'totalCount'=>$totalCount]);

    }

    public function updatePermission(Request $request) {

        //return $request->all();
        $permission_id = $request->permission_id;
        $permission_name = $request->epermission_name;


        $updateArray = [
            'name' => $permission_name,
            'updated_at' => date('Y-m-d H:i:s')
        ];
        try{
            $update = Permission::where('id',$permission_id)->update($updateArray);
        
            return response(['message'=>'Success','data'=>[]],200);
        

        } catch(\Exception $e) {

            return response(['message'=>'Server Error','data'=> $e->getMessage()],500);
        }
    }

    public function addPermission(Request $request) {

        //return $request->all();
        $permission_name = $request->permission_name;


        $insertArray = [
            'name' => $permission_name,
            'guard_name' => 'web',
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];
        try{
            # dup check
            $dup = Permission::where('name','like','%'.$permission_name.'%')->get();
            if($dup->Count()>0) {
                return response(['message'=>'Duplicate Permission Name','data'=>[]],409);
            } 
            $update = Permission::insert($insertArray);
        
            return response(['message'=>'Success','data'=>[]],200);
        

        } catch(\Exception $e) {

            return response(['message'=>'Server Error','data'=> $e->getMessage()],500);
        }
    }
}
