<?php

namespace App\Http\Controllers\Role;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Role;
use Permissions;

class RoleController extends Controller
{
    //
     /**
     * @return view of users
     */
    public function index(){
        
        return view('roles.index');
    }

    public function fetchRoles() {
        $roles = Role::all();
        $totalCount = count($roles);
        return response(['data'=>$roles,'totalCount'=>$totalCount]);

    }

    public function fetchRolePermissions(Request $request){
        $role_id = $request->role_id;
        $all_permissions = Permissons::all();
        $role = Role::where('id',$role_id)->with('permissions.permission_names')->get();
        //$role = Role::findByName('writer');
        return response(['data'=>$role,'status'=>200],200);
    }

    public function updateRole(Request $request) {

        //return $request->all();
        $role_id = $request->role_id;
        $role_name = $request->erole_name;


        $updateArray = [
            'name' => $role_name,
            'updated_at' => date('Y-m-d H:i:s')
        ];
        try{
            $update = Role::where('id',$role_id)->update($updateArray);
        
            return response(['message'=>'Success','data'=>[]],200);
        

        } catch(\Exception $e) {

            return response(['message'=>'Server Error','data'=> $e->getMessage()],500);
        }
    }

    public function addRole(Request $request) {

        //return $request->all();
        $role_name = $request->role_name;


        $insertArray = [
            'name' => $role_name,
            'guard_name' => 'web',
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];
        try{
            # dup check
            $dup = Role::where('name','like','%'.$role_name.'%')->get();
            if($dup->Count()>0) {
                return response(['message'=>'Duplicate Role Name','data'=>[]],409);
            } 
            $update = Role::insert($insertArray);
        
            return response(['message'=>'Success','data'=>[]],200);
        

        } catch(\Exception $e) {

            return response(['message'=>'Server Error','data'=> $e->getMessage()],500);
        }
    }
}
