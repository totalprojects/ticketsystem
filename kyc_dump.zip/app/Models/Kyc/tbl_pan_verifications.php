<?php

namespace App\Models\Kyc;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class tbl_pan_verifications extends Model
{
    use HasFactory;
}
