<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema;
use Illuminate\Contracts\Events\Dispatcher;
use JeroenNoten\LaravelAdminLte\Events\BuildingMenu;
use MenuMapping;
use MenuMaster;
use Auth;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot(Dispatcher $events)
    {

        $events->listen(BuildingMenu::class, function (BuildingMenu $event) {
            // Add some items to the menu...
            $event->menu->add('MAIN NAVIGATION');
            $uid = Auth::user()->id;
            $menu_access = MenuMaster::whereHas('menu_mappings', function($Q) use($uid) {
                $Q->where('user_id',$uid);
            
            })->where('status',1)->orderBy('menu_order','asc');
            $menus = [];
            $in = 0;
            $iterate = 0;
            foreach($menu_access->get() as $menu) {

                // if(stristr($menu->menu_name,'Verification')) {

                //     if($in==0) {
                //         $menus = [
                //             'text' => 'Verifications',
                //             'icon'  => 'fas fa-check-circle',
                //         ];
                       
                //     } 
                //     $menus['submenu'][$in] = [

                //         'text' => $menu->menu_name ?? '-',
                //         'route' => $menu->menu_slug ?? '-',
                //         'icon'  => $menu->icon ?? '-'
                //     ];

                //     $in++;

                    
                
                // } else {
                   
                //     if($in>0) {
                //         $event->menu->add($menus);
                //         $in=0;
                //     }
                        
                    $menus = [
                        'text' => $menu->menu_name ?? '-',
                        'route' => $menu->menu_slug ?? '-',
                        'icon'  => $menu->icon ?? '-'
                    ];

                    $event->menu->add($menus);

                    
                //}
               
                
            }

           
        });
        Schema::defaultStringLength(191);
    }
}
