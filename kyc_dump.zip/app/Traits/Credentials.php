<?php
namespace App\Traits;


trait Credentials
{
    protected $clientId = "AI5WM5NAG2TNMAXC9JVP2BVPYTBLKWS3";
    protected $clientSecret = "EHZ43KUXFU2XJTHM8JTTFY4WJC4CZ1VV";
}

?>