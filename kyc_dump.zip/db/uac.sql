-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 23, 2021 at 03:25 PM
-- Server version: 8.0.21
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `uac`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2021_04_12_085656_create_permission_tables', 1),
(5, '2021_04_12_110604_create_tbl_menu_master', 2),
(6, '2021_04_12_110544_create_tbl_articles', 3),
(7, '2021_04_12_111039_create_tbl_user_menu_mapping', 4),
(8, '2021_04_26_080111_create_tbl_bank_verification', 5),
(9, '2021_04_28_061749_create_tbl_pan_verification', 6),
(10, '2021_04_28_061758_create_tbl_aadhaar_verification', 7);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
CREATE TABLE IF NOT EXISTS `model_has_permissions` (
  `permission_id` bigint UNSIGNED NOT NULL,
  `model_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `model_has_permissions`
--

INSERT INTO `model_has_permissions` (`permission_id`, `model_type`, `model_id`) VALUES
(1, 'App\\Models\\User', 1),
(1, 'App\\Models\\User', 2),
(1, 'App\\Models\\User', 3),
(1, 'App\\Models\\User', 4),
(2, 'App\\Models\\User', 1),
(2, 'App\\Models\\User', 2),
(2, 'App\\Models\\User', 3),
(2, 'App\\Models\\User', 4),
(3, 'App\\Models\\User', 1),
(3, 'App\\Models\\User', 3),
(4, 'App\\Models\\User', 3),
(5, 'App\\Models\\User', 3);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
CREATE TABLE IF NOT EXISTS `model_has_roles` (
  `role_id` bigint UNSIGNED NOT NULL,
  `model_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\Models\\User', 4),
(2, 'App\\Models\\User', 2),
(3, 'App\\Models\\User', 3),
(5, 'App\\Models\\User', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
CREATE TABLE IF NOT EXISTS `permissions` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(125) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(125) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'Bank Verifications', 'web', '2021-04-12 03:48:25', '2021-04-27 16:52:15'),
(2, 'Aadhaar Verifications', 'web', '2021-04-12 03:48:25', '2021-04-27 16:52:35'),
(3, 'Pan Verifications', 'web', '2021-04-12 03:48:25', '2021-04-27 16:52:49'),
(4, 'Voter Id Verifications', 'web', '2021-04-12 03:48:25', '2021-04-27 16:53:09'),
(5, 'Add User', 'web', '2021-04-27 17:00:10', '2021-04-27 17:00:10');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(125) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(125) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'Minimal User', 'web', '2021-04-12 03:48:25', '2021-04-27 17:22:25'),
(2, 'Auditor', 'web', '2021-04-12 03:48:25', '2021-04-27 17:23:06'),
(3, 'Super Admin', 'web', '2021-04-12 03:48:25', '2021-04-27 17:23:17'),
(4, 'Directors', 'web', '2021-04-27 17:25:09', '2021-04-27 17:25:09'),
(5, 'Accounts', 'web', '2021-04-28 05:21:23', '2021-04-28 05:21:23');

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
CREATE TABLE IF NOT EXISTS `role_has_permissions` (
  `permission_id` bigint UNSIGNED NOT NULL,
  `role_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(1, 1),
(2, 1),
(3, 2),
(4, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_aadhaar_verifications`
--

DROP TABLE IF EXISTS `tbl_aadhaar_verifications`;
CREATE TABLE IF NOT EXISTS `tbl_aadhaar_verifications` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `crm_id` bigint UNSIGNED DEFAULT NULL,
  `verification_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '0' COMMENT 'Pan Verification Id',
  `customer_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'N/A' COMMENT 'Customer Name',
  `dob` text COLLATE utf8mb4_unicode_ci COMMENT 'Customer DOB',
  `fathers_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Customer Father Name',
  `address` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Customer Residential Address',
  `image` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Aadhaar Image',
  `gender` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Customer Gender Number',
  `status` smallint UNSIGNED NOT NULL DEFAULT '0' COMMENT '0 -> Not Verified 1 - Verified',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_aadhaar_verifications`
--

INSERT INTO `tbl_aadhaar_verifications` (`id`, `crm_id`, `verification_id`, `customer_name`, `dob`, `fathers_name`, `address`, `image`, `gender`, `status`, `created_at`, `updated_at`) VALUES
(1, 0, '444102163589', 'Joydeep Bandyopadhyay', '28/06/1992', 'NULL', 'NULL', 'C:\\wamp64\\www\\dump\\app\\storage\\app\\public\\kyc_documents/1619617881.jpg', 'Male', 1, '2021-04-28 13:42:17', '2021-04-28 13:51:28');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_articles`
--

DROP TABLE IF EXISTS `tbl_articles`;
CREATE TABLE IF NOT EXISTS `tbl_articles` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint UNSIGNED NOT NULL COMMENT 'Pk of users table',
  `title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'title of article',
  `body` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'body of the article',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bank_verifications`
--

DROP TABLE IF EXISTS `tbl_bank_verifications`;
CREATE TABLE IF NOT EXISTS `tbl_bank_verifications` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `crm_id` bigint UNSIGNED DEFAULT NULL,
  `verification_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '0' COMMENT 'Bank Verification Id',
  `customer_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'N/A' COMMENT 'Customer Name',
  `status` smallint UNSIGNED NOT NULL DEFAULT '0' COMMENT '0 -> Not Verified 1 - Verified',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_menu_masters`
--

DROP TABLE IF EXISTS `tbl_menu_masters`;
CREATE TABLE IF NOT EXISTS `tbl_menu_masters` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `menu_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'name of menu',
  `menu_slug` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'slug of menu',
  `icon` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `menu_order` tinyint NOT NULL,
  `status` tinyint DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_menu_masters`
--

INSERT INTO `tbl_menu_masters` (`id`, `menu_name`, `menu_slug`, `icon`, `menu_order`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Articles', 'articles.view', 'fas fa-newspaper', 10, 0, '2021-04-12 07:37:00', '2021-04-28 18:13:17'),
(2, 'Roles', 'roles.view', 'fas fa-users-cog', 2, 1, '2021-04-12 07:41:13', '2021-04-28 05:26:13'),
(3, 'Users', 'users.view', 'fas fa-users', 3, 1, '2021-04-12 07:41:29', '2021-04-28 05:31:22'),
(4, 'Change Password', 'user.change.password', 'fas fa-key', 4, 1, '2021-04-12 07:41:39', '2021-04-28 05:31:30'),
(5, 'Menus', 'menus.view', 'fa fa-bars', 5, 1, '2021-04-13 05:28:03', '2021-04-28 05:31:37'),
(6, 'Bank Verification', 'kyc.bank.view', 'fa fa-university', 6, 1, '2021-04-27 01:12:22', '2021-04-28 05:31:37'),
(7, 'Pan Verification', 'kyc.pan.view', 'fa fa-id-card', 7, 1, '2021-04-27 01:15:12', '2021-04-27 01:15:12'),
(8, 'Aadhaar Verification', 'kyc.adhaar.view', 'fa fa-id-badge', 8, 1, '2021-04-27 01:16:13', '2021-04-27 01:16:13'),
(9, 'Permissions', 'permissions.view', 'fa fa-lock', 9, 1, '2021-04-27 15:38:29', '2021-04-28 05:31:22'),
(10, 'Dashboard', 'home', 'fas fa-home', 1, 1, '2021-04-28 18:13:08', '2021-04-28 18:13:17');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pan_verifications`
--

DROP TABLE IF EXISTS `tbl_pan_verifications`;
CREATE TABLE IF NOT EXISTS `tbl_pan_verifications` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `crm_id` bigint UNSIGNED DEFAULT NULL,
  `verification_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '0' COMMENT 'Pan Verification Id',
  `customer_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'N/A' COMMENT 'Customer Name',
  `dob` text COLLATE utf8mb4_unicode_ci COMMENT 'Customer DOB',
  `image` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Pan Image',
  `fathers_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Customer Father Name',
  `status` smallint UNSIGNED NOT NULL DEFAULT '0' COMMENT '0 -> Not Verified 1 - Verified',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_pan_verifications`
--

INSERT INTO `tbl_pan_verifications` (`id`, `crm_id`, `verification_id`, `customer_name`, `dob`, `image`, `fathers_name`, `status`, `created_at`, `updated_at`) VALUES
(1, 0, 'AZNPB3289N', 'JOYDEEP BANDYOPADHYAY', '28/06/1992', 'C:\\wamp64\\www\\dump\\app\\storage\\app\\public\\kyc_documents/1619618002.jpg', 'SANJIB BANDYOPADHYAY', 0, '2021-04-28 13:29:57', '2021-04-28 13:53:28');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_menu_mappings`
--

DROP TABLE IF EXISTS `tbl_user_menu_mappings`;
CREATE TABLE IF NOT EXISTS `tbl_user_menu_mappings` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `menu_id` bigint UNSIGNED NOT NULL COMMENT 'Pk of menu master',
  `sub_menu_id` bigint UNSIGNED DEFAULT NULL COMMENT 'Pk of sub_menu master',
  `user_id` bigint UNSIGNED NOT NULL COMMENT 'Pk of users',
  `status` tinyint UNSIGNED NOT NULL COMMENT '0 -> Hold 1 -> Approved',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=107 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_user_menu_mappings`
--

INSERT INTO `tbl_user_menu_mappings` (`id`, `menu_id`, `sub_menu_id`, `user_id`, `status`, `created_at`, `updated_at`) VALUES
(100, 9, 0, 3, 1, '2021-04-28 18:13:34', '2021-04-28 18:13:34'),
(99, 8, 0, 3, 1, '2021-04-28 18:13:34', '2021-04-28 18:13:34'),
(98, 7, 0, 3, 1, '2021-04-28 18:13:34', '2021-04-28 18:13:34'),
(75, 4, 0, 4, 1, '2021-04-27 11:27:25', '2021-04-27 11:27:25'),
(105, 8, 0, 1, 1, '2021-04-28 18:13:41', '2021-04-28 18:13:41'),
(104, 7, 0, 1, 1, '2021-04-28 18:13:41', '2021-04-28 18:13:41'),
(97, 6, 0, 3, 1, '2021-04-28 18:13:34', '2021-04-28 18:13:34'),
(96, 5, 0, 3, 1, '2021-04-28 18:13:34', '2021-04-28 18:13:34'),
(95, 4, 0, 3, 1, '2021-04-28 18:13:34', '2021-04-28 18:13:34'),
(94, 3, 0, 3, 1, '2021-04-28 18:13:34', '2021-04-28 18:13:34'),
(34, 1, 0, 2, 1, '2021-04-13 03:32:28', '2021-04-13 03:32:28'),
(35, 3, 0, 2, 1, '2021-04-13 03:32:28', '2021-04-13 03:32:28'),
(36, 4, 0, 2, 1, '2021-04-13 03:32:28', '2021-04-13 03:32:28'),
(93, 2, 0, 3, 1, '2021-04-28 18:13:34', '2021-04-28 18:13:34'),
(74, 1, 0, 4, 1, '2021-04-27 11:27:25', '2021-04-27 11:27:25'),
(103, 6, 0, 1, 1, '2021-04-28 18:13:41', '2021-04-28 18:13:41'),
(76, 6, 0, 4, 1, '2021-04-27 11:27:25', '2021-04-27 11:27:25'),
(77, 7, 0, 4, 1, '2021-04-27 11:27:25', '2021-04-27 11:27:25'),
(78, 8, 0, 4, 1, '2021-04-27 11:27:25', '2021-04-27 11:27:25'),
(92, 1, 0, 3, 1, '2021-04-28 18:13:34', '2021-04-28 18:13:34'),
(102, 4, 0, 1, 1, '2021-04-28 18:13:41', '2021-04-28 18:13:41'),
(101, 10, 0, 3, 1, '2021-04-28 18:13:34', '2021-04-28 18:13:34'),
(106, 10, 0, 1, 1, '2021-04-28 18:13:41', '2021-04-28 18:13:41');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Example User', 'test@example.com', '2021-04-12 03:48:25', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '4gsJOVOy7Sy2YMu1SBAgGocUiJH5uK2b8RkQIhahKlOayt2CTGQx4CZK0Wx2', '2021-04-12 03:48:25', '2021-04-28 18:14:37'),
(2, 'Example Admin User', 'admin@example.com', '2021-04-12 03:48:25', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'B0aFbY7yBX', '2021-04-12 03:48:25', '2021-04-12 03:48:25'),
(3, 'Example Super-Admin User', 'superadmin@example.com', '2021-04-12 03:48:25', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'tSM07ZvCAhzLbTraXEIFo0Wp3DZoYYIGvB5eJQNE9dF2nRyYZ3AGj0khfFlS', '2021-04-12 03:48:25', '2021-04-28 18:14:09'),
(4, 'Joydeep Banerjee', 'tuffguyjoy90@gmail.com', NULL, '$2y$10$LBuB/3JEKOhyAFiCpiPCju2AgqDG5.Y7/du7/o0SrrvJb832w5HE6', NULL, '2021-04-12 03:53:44', '2021-04-12 03:53:44');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
