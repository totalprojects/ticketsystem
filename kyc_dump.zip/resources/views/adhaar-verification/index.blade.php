@extends('adminlte::page')

@section('title', 'Bank Verification')

@section('content_header')
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="csrf-token" content="{{ csrf_token() }}">
  
@stop

@section('content')

    <div class="tab-content p-1">
        <div class="loading loadr d-none">Loading&#8230;</div>
        <div class="font-weight-bold m-2 font-italic text-primary"><h4 class="right">Aadhaar Verification </h4>
        <span><span class="text-red">*</span> <i>Upload jpg/png image under 7 mb</i></span>
        </div>
        <div class="tab-pane active dx-viewport" id="users">
       

            <div class="row pan_card_verification_block pt-2">
              <!-- Upload  -->
              <form id="kyc_adhaar_frm" class="uploader" enctype="multipart/form-data" style="min-width:95%">
              <div class="row">
              <div class="col-lg-6">
                <h4 class="text-center">Upload Aadhaar Card Front Side</h4>
                <input id="file-upload" type="file" class="pan_front" name="pan_front" accept="image/*" />

                <label for="file-upload" id="file-drag">
                  <img id="file-image" src="#" alt="Preview" class="hidden">
                  <div id="start">
                    <i class="fa fa-download" aria-hidden="true"></i>
                    <div>Select a file or drag here</div>
                    <div id="notimage" class="hidden">Please select an image</div>
                    <span id="file-upload-btn" class="btn btn-primary">Select a file</span>
                  </div>
                  <div id="response" class="hidden">
                    <div id="messages"></div>
                    <progress class="progress" id="file-progress" value="0">
                      <span>0</span>%
                    </progress>
                  </div>
                </label>
              </div>
              <div class="col-lg-6">
                <h4 class="text-center">Upload Aadhaar Card Back Side</h4>

                <!-- Upload  -->
                <input id="file-upload" type="file" class="pan_back" name="pan_back" accept="image/*" />

                <label for="file-upload" id="file-drag">
                  <img id="file-image" src="#" alt="Preview" class="hidden">
                  <div id="start">
                    <i class="fa fa-download" aria-hidden="true"></i>
                    <div>Select a file or drag here</div>
                    <div id="notimage" class="hidden">Please select an image</div>
                    <span id="file-upload-btn" class="btn btn-primary">Select a file</span>
                  </div>
                  <div id="response" class="hidden">
                    <div id="messages"></div>
                    <progress class="progress" id="file-progress" value="0">
                      <span>0</span>%
                    </progress>
                  </div>
                </label>
              </div>
              <div class="col-lg-6">
                <button class="btn btn-primary" id="adhaar-verification-btn" disabled> Continue <i class='fa fa-arrow-right'></i></button>

              </div>
              <div class="col-lg-12">
                <div id="verification_response_block"></div>
              </div>
              </div>
              </form>
        </div>
    </div>
    
@stop


@section('js')

    <script>
    

 
    $(document).on('click',"#adhaar-verification-btn", (r) => {
      r.preventDefault();
      var front_side =  $('.pan_front').prop('files')[0];
      var back_side = $(".pan_back").prop('files')[0];
      console.log(front_side);
      var form_data = new FormData(); 
      form_data.append('pan_front',front_side);
      form_data.append('pan_back',back_side);
      var url = "{{ route('kyc.adhaar.verify') }}";
      if(front_side) {
          $(".loadr").removeClass('d-none');
          $.ajax({
            url:url,
            data:form_data,
            dataType: 'json',
            headers:{
               'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
            },
            cache: false,
            contentType: false,
            processData: false,
            data: form_data,                         
            type: 'post',
            error: (r) => {
              console.log(r)
            },
            success: function(r){
                $(".loadr").addClass('d-none');
                $(".pan_front").val('');
                //$("#file-image").attr('src','');
                            $(".loadr").addClass('d-none');
                            if(r.message=="success") {
                            var dset = r.data;
                            // var verified_block = ``
                            // if(dset.verified==true) {
                            //     verified_block += `<span class='badge badge-success'>Yes</span>`
                            // } else {
                            //     verified_block += `<span class='badge badge-danger'>No</span>`
                            // }
                            if(dset.id_type!="AADHAAR"){
                                toastr.error('To document uploaded is not a aadhaar card, try again.')
                                return false;
                            }
                            var html = `<div class='row bg-light shadow p-4'>
                            <div class='col-lg-12'><h4>Response from Digio</h4></div>
                            <div class='col-lg-3'>
                            <span>Verification Id: </span> <span class='badge badge-warning'>${dset.id_no}</span>
                            </div>
                            <div class='col-lg-2'>
                            <span>Id Type: </span> <span class='badge badge-warning'>${dset.id_type}</span>
                            </div>
                            <div class='col-lg-2 '>
                            <span>Gender: </span> <span class='badge badge-warning'>${dset.gender}</span>
                            </div>
                            <div class='col-lg-3'>
                            <span>Name: </span> <span class='badge badge-warning'>${dset.name}</span>
                            </div>
                            <div class='col-lg-2'>
                            <span>DOB: </span> <span class='badge badge-warning'>${dset.dob}</span>
                            </div>
                            </div>`;
                            $("#verification_response_block").html(html);

                            } else {

                                toastr.error('Provided details are incorrect');
                                    return false;
                                
                                if(r.data !== undefined) {
                                
                                var err_data = r.data;
                                } else {
                                    toastr.error('Provided details are incorrect');
                                    return false;
                                }
                                var sanitized_err = err_data.split("`")[1];
                                toastr.error(JSON.stringify(sanitized_err));
                                sanitized_err = JSON.parse(sanitized_err);
                                if(sanitized_err.message !== undefined) {
                                    toastr.error(sanitized_err.message);
                                } else {
                                    toastr.error('Provided details are incorrect');
                                }
                            }
                console.log(response)

               
            }
          })
      } else {
          toastr.error('No image provided');
      }
    })
        // File Upload
// 
function ekUpload(){
  function Init() {

    console.log("Upload Initialised");

    var fileSelect    = document.getElementById('file-upload'),
        fileDrag      = document.getElementById('file-drag'),
        submitButton  = document.getElementById('submit-button');

    fileSelect.addEventListener('change', fileSelectHandler, false);

    // Is XHR2 available?
    var xhr = new XMLHttpRequest();
    if (xhr.upload) {
      // File Drop
      fileDrag.addEventListener('dragover', fileDragHover, false);
      fileDrag.addEventListener('dragleave', fileDragHover, false);
      fileDrag.addEventListener('drop', fileSelectHandler, false);
    }
  }

  function fileDragHover(e) {
    var fileDrag = document.getElementById('file-drag');

    e.stopPropagation();
    e.preventDefault();

    fileDrag.className = (e.type === 'dragover' ? 'hover' : 'modal-body file-upload');
  }

  function fileSelectHandler(e) {
    // Fetch FileList object
    var files = e.target.files || e.dataTransfer.files;

    // Cancel event and hover styling
    fileDragHover(e);

    // Process all File objects
    for (var i = 0, f; f = files[i]; i++) {
      parseFile(f);
      uploadFile(f);
    }
  }

  // Output
  function output(msg) {
    // Response
    var m = document.getElementById('messages');
    m.innerHTML = msg;
  }

  function parseFile(file) {

    console.log(file.name);
    if(file.name !== undefined) {
     
          $("#adhaar-verification-btn").prop('disabled',false);
       
    } else {

      $("#adhaar-verification-btn").prop('disabled',true);
    }
    output(
      '<strong>' + encodeURI(file.name) + '</strong>'
    );
    
    // var fileType = file.type;
    // console.log(fileType);
    var imageName = file.name;

    var isGood = (/\.(?=gif|jpg|png|jpeg)/gi).test(imageName);
    if (isGood) {
      document.getElementById('start').classList.add("hidden");
      document.getElementById('response').classList.remove("hidden");
      document.getElementById('notimage').classList.add("hidden");
      // Thumbnail Preview
      document.getElementById('file-image').classList.remove("hidden");
      document.getElementById('file-image').src = URL.createObjectURL(file);
    }
    else {
      toastr.error('Image type not supported');
      document.getElementById('file-image').classList.add("hidden");
      document.getElementById('notimage').classList.remove("hidden");
      document.getElementById('start').classList.remove("hidden");
      document.getElementById('response').classList.add("hidden");
      document.getElementById("file-upload-form").reset();
    }
  }

  function setProgressMaxValue(e) {
    var pBar = document.getElementById('file-progress');

    if (e.lengthComputable) {
      pBar.max = e.total;
    }
  }

  function updateFileProgress(e) {
    var pBar = document.getElementById('file-progress');

    if (e.lengthComputable) {
      pBar.value = e.loaded;
    }
  }

  function uploadFile(file) {

    var xhr = new XMLHttpRequest(),
      fileInput = document.getElementById('class-roster-file'),
      pBar = document.getElementById('file-progress'),
      fileSizeLimit = 1024; // In MB
    if (xhr.upload) {
      // Check if file is less than x MB
      if (file.size <= fileSizeLimit * 1024 * 1024) {
        // Progress bar
        pBar.style.display = 'inline';
        xhr.upload.addEventListener('loadstart', setProgressMaxValue, false);
        xhr.upload.addEventListener('progress', updateFileProgress, false);

        // File received / failed
        xhr.onreadystatechange = function(e) {
          if (xhr.readyState == 4) {
            // Everything is good!

            // progress.className = (xhr.status == 200 ? "success" : "failure");
            // document.location.reload(true);
          }
        };

      } else {
        toastr.error('Please upload a smaller file (< ' + fileSizeLimit + ' MB).');
      }
    }
  }

  // Check for the various File API support.
  if (window.File && window.FileList && window.FileReader) {
    Init();
  } else {
    document.getElementById('file-drag').style.display = 'none';
  }
}
ekUpload();
    
    </script>
@stop
