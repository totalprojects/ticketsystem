@extends('adminlte::page')

@section('title', 'Bank Verification')

@section('content_header')
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="csrf-token" content="{{ csrf_token() }}">
  
@stop

@section('content')

    <div class="tab-content p-1">
        <div class="loading loadr d-none">Loading&#8230;</div>
        <div class="font-weight-bold m-2 font-italic text-primary"><h4 class="right">Bank Verification </h4></div>
        <div class="tab-pane active dx-viewport" id="users">
            <form method="post" enctype="multipart-form/data" id="kyc_bank_frm">
                <div class="row m-2 p-2">
                    <div class="col-md-2">
                        <label>Enter Bank Account No</label>
                    </div>
                    <div class="col-md-4">
                        <input type="number" id="account_no" name="account_no" class="form-control" placeholder="Enter Bank Account No">
                    </div>
                    <div class="col-md-2">
                        <label>Enter Bank IFSC Code</label>
                    </div>
                    <div class="col-md-4">
                        <input type="text" id="ifsc_code" name="ifsc_code" class="form-control" placeholder="Enter Ifsc Code">
                    </div>
                    <div class="col-md-2">
                        <button name="verify_bank_btn" id="verify_bank_btn" class="btn btn-primary m-1 p-2">Verify</button>
                    </div>
                    <div class="col-md-12">
                        <div id="verification_response_block" class="p-1 m-1"></div>
                    </div>
                </div>
            </form>
           
        </div>
    </div>
    
@stop

@section('css')
    <link rel="stylesheet" href="{{ asset('assets/custom/main.css') }}">
@stop

@section('js')

    <script>
    
        $(document).on('click',"#verify_bank_btn", (e) => {
            e.preventDefault();
            var account_no = $("#account_no").val();
            var ifsc_code = $("#ifsc_code").val();

            if(account_no.length < 9 || account_no.length > 22 || account_no.length == 0) {

                toastr.error('Account number must be between 9 to 22 digits');
                return false;
            }
            if(ifsc_code.length==0) {

                toastr.error('Kindly provide the IFSC Code');
                return false;
            }

            var url = "{{  route('kyc.bank.verify') }}"
                    $.ajax({
                        url:url,
                        data:{account_no:account_no,ifsc_code:ifsc_code},
                        type:"POST",
                        headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                        },
                        beforeSend:(r) => {
                            $(".loadr").removeClass('d-none');
                        },
                        error:(r) => {
                            $(".loadr").addClass('d-none');
                            var err = r.responseJSON;
                            if(err.data !== undefined) {
                                var err_data = err.data;
                            } else {
                                toastr.error('Provided details are incorrect');
                                return false;
                            }
                            var sanitized_err = err_data.split("\n")[1];
                            sanitized_err = JSON.parse(sanitized_err);
                            if(sanitized_err.message !== undefined) {
                                toastr.error(sanitized_err.message);
                            } else {
                                toastr.error('Provided details are incorrect');
                            }
                        },
                        success:(r) => {

                            $("#kyc_bank_frm")[0].reset();
                            $(".loadr").addClass('d-none');
                            if(r.message=="success") {
                            var dset = r.data;
                            var verified_block = ``
                            if(dset.verified==true) {
                                verified_block += `<span class='badge badge-success'>Yes</span>`
                            } else {
                                verified_block += `<span class='badge badge-danger'>No</span>`
                            }
                            var html = `<div class='row bg-light shadow p-4'>
                            <div class='col-lg-12'><h4>Response from Digio</h4></div>
                            <div class='col-lg-3'>
                            <span>Verification Id: </span> <span class='badge badge-warning'>${dset.id}</span>
                            </div>
                            <div class='col-lg-4'>
                            <span>Beneficiary name: </span> <span class='badge badge-warning'>${dset.beneficiary_name_with_bank}</span>
                            </div>
                            <div class='col-lg-2'>
                            <span>Verified: </span> ${verified_block}
                            </div>
                            <div class='col-lg-3'>
                            <span>Verified At </span> <span class='badge badge-warning'>${dset.verified_at}</span>
                            </div>
                            </div>`;
                            $("#verification_response_block").html(html);

                            } else {
                                if(r.data !== undefined) {
                                var err_data = r.data;
                                } else {
                                    toastr.error('Provided details are incorrect');
                                    return false;
                                }
                                var sanitized_err = err_data.split("\n")[1];
                                sanitized_err = JSON.parse(sanitized_err);
                                if(sanitized_err.message !== undefined) {
                                    toastr.error(sanitized_err.message);
                                } else {
                                    toastr.error('Provided details are incorrect');
                                }
                            }
                        }
                    })


        })
    
    </script>
@stop
