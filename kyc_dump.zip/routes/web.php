<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', function () {
    return redirect()->to('/home');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->middleware('auth')->name('home');

/** All Views */
Route::group(['prefix' => 'app','middleware' => ['auth','permissions']], function () {
    
   
    Route::get('/change-password', [App\Http\Controllers\User\UserController::class, 'changePasswordPage'])->name('user.change.password');

    Route::get('/users', [App\Http\Controllers\User\UserController::class, 'index'])->name('users.view');

    Route::get('/articles', [App\Http\Controllers\Article\ArticleController::class, 'index'])->name('articles.view');

    Route::get('/roles', [App\Http\Controllers\Role\RoleController::class, 'index'])->name('roles.view');

    Route::get('/menus', [App\Http\Controllers\Menu\MenuController::class, 'index'])->name('menus.view');
    
    Route::get('/permissions', [App\Http\Controllers\Permission\PermissionController::class, 'index'])->name('permissions.view');

    /** Kyc Section */
    Route::get('/banking-verification', [App\Http\Controllers\Kyc\BankController::class, 'index'])->name('kyc.bank.view');

    Route::get('/adhaar-verification', [App\Http\Controllers\Kyc\AdhaarController::class, 'index'])->name('kyc.adhaar.view');

    Route::get('/pan-verification', [App\Http\Controllers\Kyc\PanController::class, 'index'])->name('kyc.pan.view');
});

/** Ajax Calls */
Route::group(['prefix' => 'ajax'], function () {
    
    Route::get('/users-list/{token}', [App\Http\Controllers\User\UserController::class, 'fetchUsers'])->name('users.list');

    Route::post('update/user/permission', [App\Http\Controllers\User\UserController::class, 'updatePermissions'])->name('update.user.permissions');
    
    Route::post('update/user/role', [App\Http\Controllers\User\UserController::class, 'updateRole'])->name('update.user.roles');

    Route::post('update/user/menus', [App\Http\Controllers\User\UserController::class, 'updateMenus'])->name('update.user.menus');

    Route::get('menu/list', [App\Http\Controllers\Menu\MenuController::class, 'fetchMenus'])->name('get.menu.list');

    Route::post('menu/add', [App\Http\Controllers\Menu\MenuController::class, 'addMenu'])->name('add.menu');

    Route::post('menu/reorder', [App\Http\Controllers\Menu\MenuController::class, 'reorderMenu'])->name('menu.reorder');

    Route::get('role/list', [App\Http\Controllers\Role\RoleController::class, 'fetchRoles'])->name('get.roles.list');

    Route::get('role/permissions', [App\Http\Controllers\Role\RoleController::class, 'fetchRolePermissions'])->name('show.role.permissions');

    Route::get('/permissions-list', [App\Http\Controllers\Permission\PermissionController::class, 'fetchPermissions'])->name('show.permissions');

    Route::post('/verify-bank-details', [App\Http\Controllers\Kyc\BankController::class, 'verifyBank'])->name('kyc.bank.verify');

    Route::post('/verify-pan-details', [App\Http\Controllers\Kyc\PanController::class, 'verifyPanCard'])->name('kyc.pan.verify');

    Route::post('/verify-adhaar-details', [App\Http\Controllers\Kyc\AdhaarController::class, 'verifyAdhaarCard'])->name('kyc.adhaar.verify');

    Route::post('/update-menu', [App\Http\Controllers\Menu\MenuController::class, 'updateMenu'])->name('update.menu');

    Route::post('/update-permission', [App\Http\Controllers\Permission\PermissionController::class, 'updatePermission'])->name('update.permission');

    Route::post('/add-permission', [App\Http\Controllers\Permission\PermissionController::class, 'addPermission'])->name('add.permission');

    Route::post('/add-role', [App\Http\Controllers\Role\RoleController::class, 'addRole'])->name('add.role');
    
    Route::post('/update-role', [App\Http\Controllers\Role\RoleController::class, 'updateRole'])->name('update.role');
});