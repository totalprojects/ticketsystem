<?php $__env->startSection('title', 'Menus'); ?>

<?php $__env->startSection('content_header'); ?>
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style>
    label.error {
        color:darkred;
        font-size: 12px;
    }
</style>
    <div class="tab-content p-1">
        <div class="font-weight-bold font-italic text-primary"><p class="right">Menu List </p></div>
        <div class="tab-pane active dx-viewport" id="users">
            <div class="demo-container p-3">
                <button id="add_menu" class='btn btn-primary p-1'><i class='fa fa-plus'></i> Menu</button>
                <div id="menu-list-div" style="height:600px"></div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="add-menu-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Add Menu</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                <form method="post" id="menu-frm">
                    <div class="row">
                        <div class="col-lg-4 form-group">
                            <label for="menu_name">Menu Name <span class='man'>*</span></label>
                            <input type="text" name="menu_name" id="menu_name" placeholder="Enter Menu name" class="form-control">
                        </div>
                        <div class="col-lg-4 form-group">
                            <label for="menu_name">Menu Slug <span class='man'>*</span></label>
                            <input type="text" name="menu_slug" id="menu_slug" placeholder="Enter Menu slug" class="form-control">
                        </div>
                        <div class="col-lg-4 form-group">
                            <label for="menu_name">Menu Icon Code <span class='man'>*</span></label>
                            <input type="text" name="menu_icon" id="menu_icon" placeholder="Enter Menu icon" class="form-control">
                        </div>
                        <div class="col-lg-8 form-group">
                            <span></span>
                            <input type="submit" name="add-menu-btn" id="add-menu-btn" class="btn btn-primary">
                        </div>

                    </div>
                </form>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              
            </div>
          </div>
        </div>
      </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>
    <script>
$(document).on('click','#add-menu-btn', ()=> {
    $("#menu-frm").validate({
        rules:{
            menu_name:{
                required:true
            },
            menu_slug:{
                required:true
               // pattern:
            },
            menu_icon:{
                required:true
            }
        },
        submitHandler:(r) => {
            var url = "<?php echo e(route('add.menu')); ?>"
            $.ajax({
                url:url,
                data:$("#menu-frm").serialize(),
                type:"POST",
                headers: {
                   'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                },
                beforeSend:(r) => {
                    $("#add-menu-btn").prop('disabled',true);
                },
                error:(r) => {
                    $("#add-menu-btn").prop('disabled',false);
                    toastr.error('Something went wrong');
                },
                success:(r) => {
                    $("#add-menu-btn").prop('disabled',false);
                    toastr.success('Menu Added successfully');
                    $("#menu-frm").modal('hide');
                    fetch_data();
                }

            })
        }
    });
})
$(document).on('click','#add_menu', ()=> {
   // console.log('inn')
    $("#add-menu-modal").modal('show');
});
fetch_data();
function fetch_data(){
    function isNotEmpty(value) {
        return value !== undefined && value !== null && value !== "";
    }
   var jsonData = new DevExpress.data.CustomStore({
       key: "id",
       load: function (loadOptions) {
           // console.log(loadOptions)
           var deferred = $.Deferred(),
               args = {};
           [
               "skip",
               "take",
               "requireTotalCount",
               "sort",
               "filter",
           ].forEach(function (i) {
               if (i in loadOptions && isNotEmpty(loadOptions[i]))
                   args[i] = JSON.stringify(loadOptions[i]);
           })

           let take = loadOptions.take
           let skip = loadOptions.skip
           var dataSet = []
           var url = "<?php echo e(route('get.menu.list')); ?>"
           $.ajax({
               url: url,
               type: 'GET',
               headers: {
                   'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
               },
               dataType: "json",
               data: '&take=' + take + '&skip=' + skip,
               complete: function (result) {
                   var res = result.responseJSON;
                   var data = res.data;
                   console.log(res)
                   deferred.resolve(data, {
                       totalCount: res.totalCount,
                   });
                   
               },
               error: function () {
                   deferred.reject("Data Loading Error");
               },
               //timeout: 2000000
           });
           return deferred.promise();
       }
   });
   $("#menu-list-div").dxDataGrid({
       dataSource: jsonData,
       KeyExpr: "id",
       showBorders: true,
       showRowLines: true,
       rowAlternationEnabled: true,
       allowColumnResizing: true,
       sorting: false,
       loadPanel: {
        //indicatorSrc: `${ASSET_URL}/assets/images/loader4.gif`,
        text: "Loading...",
        showPane: true,
       },
       remoteOperations: {
           filtering: true,
           paging: true,
           sorting: true,
           groupPaging: true,
           grouping: true,
           summary: true
       },
       paging: {
           enabled: true,
           pageSize: 10
       },
       columnChooser: {
           enabled: true,
           mode: "select" // or "dragAndDrop"
       },
    //    searchPanel: {
    //        visible: true,
    //        width: 240,
    //        placeholder: "Search..."
    //    },
       headerFilter: {
           //visible: true
       },
       scrolling: {
           scrollByContent: true,
       },
       sorting: {
            mode: "none"
        },
        rowDragging: {
            allowReordering: true,
                dropFeedbackMode: "push",
                onReorder: function(e) {
                    var visibleRows = e.component.getVisibleRows(),
                        newOrderIndex = visibleRows[e.toIndex].data.id,
                        shiftedItemOrder = visibleRows[e.toIndex].data.menu_order;
                        d = $.Deferred();
                        var draggedItemOrder = e.itemData.menu_order;
                        var draggedItem = e.itemData.id;
                        var shiftedItem = newOrderIndex;
                        var url = "<?php echo e(route('menu.reorder')); ?>"
                        $.ajax({
                            url:url,
                            data:{draggedItem:draggedItem,shiftedItem:shiftedItem,draggedItemOrder:draggedItemOrder,shiftedItemOrder:shiftedItemOrder},
                            type:"POST",
                            headers:{
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                            },
                            beforeSend:(r) => {

                            },
                            error:(r)=> {
                                console.log(r.responseText)
                            },
                            success:(r) => {
                                if(r==1) {
                                    toastr.success('Menu Items order updated successfully');
                                    fetch_data();
                                } else {
                                    console.log(r)
                                }
                            }
                        })
                    // tasksStore.update(e.itemData.ID, { OrderIndex: newOrderIndex }).then(function() {
                    //     e.component.refresh().then(d.resolve, d.reject);
                    // }, d.reject);

                   // e.promise = d.promise();
                }
        },
       wordWrapEnabled: true,
       columns: [{
               dataField: "id",
               caption: "Menu Id",
               width:50,
               visibe: true,
           },
           {
               dataField: "menu_name",
               caption: "Menu Name",
           },
           {
               dataField: "menu_slug",
               caption: "Menu Slug",
           },
           {
               dataField: "Action",
               caption: "Action",
               width:100,
               cellTemplate: function (container, options) {
                   var json_string = JSON.stringify(options.data);
                   console.log(json_string)
                //var href = `<a data-type="edit" data-json=${options.data} data-id=${options.data.gift_id} data-url=${ route('mason.gift.update', options.data.gift_id) } class="edit-icon action_icon" href="javascript:void(0)" title="edit"><i class="fas fa-edit edit_icon"></i></a>`;
                var link = $(`<a href="javascript:void(0)" title="edit">`).html("<i class='fa fa-edit'></i> Action")
                    .attr("href", "javascript:void(0)")

                link.on("click", function () {
                   
                })
                
                return link;

               }
           },
       ],
   });
    
}

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\dump\app\resources\views/menus/index.blade.php ENDPATH**/ ?>